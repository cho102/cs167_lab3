javac src/main/java/edu/ucr/cs/cs167/cho102/App.java
java src/main/java/edu/ucr/cs/cs167/cho102/App.java 3 20 5
java src/main/java/edu/ucr/cs/cs167/cho102/App.java 3 20 3,5
java src/main/java/edu/ucr/cs/cs167/cho102/App.java 3 20 3v5
