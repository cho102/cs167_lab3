# Lab 3

## Student information

* Full name: Cindy Ho
* E-mail: cho102@ucr.edu
* UCR NetID: cho102
* Student ID: 862151318

## Answers

- **(Q1)** Which of the following is the right way to call the `IsEven` function.
    - new IsEven().apply(5)

- **(Q2)** Did the program compile?
    - The program was able to compile when I add base=0 after the printNumbers function in the else section since that is where base was declared. However, when added base=0 at the end of the if/else statement, it wasn't able to compile.

- **(Q3)** If it does not work, what is the error message you get?
